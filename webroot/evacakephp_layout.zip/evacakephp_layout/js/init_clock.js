$(document).ready(function(){
	var optionsjclock = {
        format: '%Y-%m-%d %H:%M:%S' // 24-hour
    } 
    /*clock*/
	$('#jclock').jclock(optionsjclock);
});