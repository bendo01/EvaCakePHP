// JavaScript Document
$(document).ready(function(){
	/*button and date picker*/
	$('.jqui_datepicker').datepicker({ dateFormat: 'yy-mm-dd' });
	$('input:submit').button();
	$('div.submit button, input:submit').button();
	$('div.actions ul li a.add_new_data').button({
		icons:{primary:'ui-icon-plus'}
	});
	$('table.mylayout tbody tr.odd td.actions a.action_table_view_data').button({
		text: false,
		icons:{primary:'ui-icon-info'}
	});
	$('table.mylayout tbody tr.odd td.actions a.action_table_edit_data').button({
		text: false,
		icons:{primary:'ui-icon-pencil'}
	});
	$('table.mylayout tbody tr.odd td.actions a.action_table_delete_data').button({
		text: false,
		icons:{primary:'ui-icon-circle-close'}
	});
	
	$('table.mylayout tbody tr td.actions a.action_table_view_data').button({
		text: false,
		icons:{primary:'ui-icon-info'}
	});
	$('table.mylayout tbody tr td.actions a.action_table_edit_data').button({
		text: false,
		icons:{primary:'ui-icon-pencil'}
	});
	$('table.mylayout tbody tr td.actions a.action_table_delete_data').button({
		text: false,
		icons:{primary:'ui-icon-circle-close'}
	});
	/*paginate option*/
	$('div.paging > span.disabled').button({ 
		disabled: true,
		icons:{primary:'ui-icon-seek-prev'}
	});
	$('div.paging > span > a.prev').button({
		icons:{primary:'ui-icon-seek-prev'},
	});
	$('div.paging > span.current').button();
	$('div.paging > span > a').button();
	$('div.paging > span > a.next').button({
		icons:{secondary:'ui-icon-seek-next'}
	});
	/*accordion option*/
	$('#accordion').accordion({ autoHeight: false });
	/*
	if($('div#flashMessage').length != 0 && $('.form-error').length != 0){
		$.jGrowl($('div#flashMessage').text(),{ sticky: true , theme: 'ui-state-error'});
		$('div#flashMessage').remove();
			if($('.form-error').length != 0){
				$('.form-error').each(function(){
					var labelname = $(this).prev().text();
					var errormessage = $(this).next().text();
					$(this).next().hide();
					$.jGrowl(labelname + ' ' + errormessage,{ sticky: true, theme: 'ui-state-error'});
				});
			}
	}
	*/
	/*
	if($('div#flashMessage').length != 0 && $('.form-error').length != 0){
		$.jGrowl($('div#flashMessage').text(),{ sticky: true , theme: 'message'});
		$('div#flashMessage').remove();
		$.jGrowl($('div#flashMessage3').text(),{ sticky: true , theme: 'notice'});
		$('div#flashMessage3').remove();
		$.jGrowl($('div#flashMessage2').text(),{ sticky: true , theme: 'success'});
		$('div#flashMessage2').remove();
			if($('.form-error').length != 0){
				$('.form-error').each(function(){
					var labelname = $(this).prev().text();
					var errormessage = $(this).next().text();
					$(this).next().hide();
					$.jGrowl(labelname + ' ' + errormessage,{ sticky: true, theme: 'error-message'});
				});
			}
	}
	
	if($('div#flashMessage').length != 0 && $('.form-error').length == 0){
		$.jGrowl($('div#flashMessage').text(),{ life: 5000 });
		$('div#flashMessage').remove();
	}*/
	
	/*fancybox modal form*/
	
	$("#various5").fancybox({
	        'transitionIn'		: 'none',
			'transitionOut'		: 'none',
			'type'				: 'ajax',
			onComplete	        : function(){
				if($('div#flashMessage').length != 0 && $('.form-error').length != 0){
					$.jGrowl($('div#flashMessage').text(),{ sticky: true , theme: 'message'});
					$('div#flashMessage').remove();
					$.jGrowl($('div#flashMessage3').text(),{ sticky: true , theme: 'notice'});
					$('div#flashMessage3').remove();
					$.jGrowl($('div#flashMessage2').text(),{ sticky: true , theme: 'success'});
					$('div#flashMessage2').remove();
					if($('.form-error').length != 0){
						$('.form-error').each(function(){
							var labelname = $(this).prev().text();
							var errormessage = $(this).next().text();
							$(this).next().hide();
							$.jGrowl(labelname + ' ' + errormessage,{ sticky: true, theme: 'error-message'});
						});
					}
				}
				//$('#EvaApplicationDescription').markItUp(mySettings);
				$('#EvaApplicationDeleted').button();
			},
			onClosed           : function(){
				$("div.jGrowl").jGrowl("close");
			}
	});
	
	
});